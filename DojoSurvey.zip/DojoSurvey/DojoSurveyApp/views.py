from django.shortcuts import HttpResponse, render, redirect
def index(request):
    return render(request, "index.html")

def result(request):
    print("*" * 50)
    print(request.method)
    print("PRINTING RESUEST.POST (INFO COLELCTED FROM FORM) BELOW")
    print(request.POST)#info collected from the form it is submitted

    name_on_form = request.POST["studentName"]
    location_on_form = request.POST["dojoLocation"]
    favorite_language_on_form = request.POST["favLanguage"]
    comment_on_form = request.POST["info"]

    context = {
        "studentName" : name_on_form,
        "dojoLocation": location_on_form,
        "favLanguage" : favorite_language_on_form,
        "info" : comment_on_form
    }
    return render(request, "request.html", context)

def main(request):
    return redirect('index.html')

